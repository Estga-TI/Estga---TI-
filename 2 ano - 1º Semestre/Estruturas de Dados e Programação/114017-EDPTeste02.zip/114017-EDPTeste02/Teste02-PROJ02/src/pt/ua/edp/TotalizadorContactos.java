package pt.ua.edp;

import java.io.*;
import java.util.Date;

public class TotalizadorContactos implements Serializable {
    private Date instante;
    private int total;

    // Método para obter o instante
    public Date getInstante() {
        return instante;
    }

    // Método para definir o instante
    public void setInstante(Date instante) {
        this.instante = instante;
    }

    // Método para obter o total
    public int getTotal() {
        return total;
    }

    // Método para definir o total
    public void setTotal(int total) {
        this.total = total;
    }

    // Método para salvar o objeto atual em um arquivo XML
    public void saveFile() throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("totalizadorContactos.xml"))) {
            oos.writeObject(this);
        }
    }

    // Método toString para representação de texto do objeto
    @Override
    public String toString() {
        return "TotalizadorContactos{\n" +
                "instante=" + instante +
                ",\ntotal=" + total +
                "\n}";
    }
}

