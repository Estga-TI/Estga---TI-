package pt.ua.edp;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
/*
NOTE BEM: este projeto tal como é apresentado não se encontra funcional. Deve usar-se como referência para responder à prova da disciplina.
 */
public class Main {


    public static void main(String[] args) throws IOException {
        Contador contador = new Contador();
        List<LeitorCSV> ficheiros = new ArrayList<>();

        File folder = new File("ficheiros");
        File[] listOfFiles = folder.listFiles();
        for (File file : listOfFiles) {
            if (file.isFile() && file.getName().endsWith(".csv")) {
                ficheiros.add(new LeitorCSV(contador, file.getAbsolutePath()));
            }
        }

        //Percorre todos os ficheiros, lança todas as threads e faz o respectivo join.
        for (LeitorCSV leitor : ficheiros) {
            leitor.start();
        }
        for (LeitorCSV leitor : ficheiros) {
            try {
                leitor.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        
        //Apresenta resultados na consola e serializa o resultado.
        /*
        TotalizadorContactos t = new TotalizadorContactos(new Date(), contador.obterValor());
        System.out.println(t.toString());
        t.SaveFile();
         */
    }
}
