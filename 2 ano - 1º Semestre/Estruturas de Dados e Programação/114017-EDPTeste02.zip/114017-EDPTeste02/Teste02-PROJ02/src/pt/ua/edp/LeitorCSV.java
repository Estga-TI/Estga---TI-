package pt.ua.edp;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

class LeitorCSV extends Thread {
    private Contador contador;
    private String ficheiro;

    // Construtor que recebe um objeto Contador e o caminho do arquivo CSV
    public LeitorCSV(Contador contador, String ficheiro) {
        this.contador = contador;
        this.ficheiro = ficheiro;
    }

    // Método que será executado quando a thread for iniciada
    public void run() {
        try (BufferedReader br = new BufferedReader(new FileReader(ficheiro))) {
            String linha;
            // Padrão para encontrar números de telefone no formato especificado
            Pattern pattern = Pattern.compile("\\+\\d{3} \\d{3} \\d{3} \\d{3}");

            // Lê cada linha do arquivo CSV
            while ((linha = br.readLine()) != null) {
                // Divide a linha em partes usando ';' como delimitador
                String[] partes = linha.split(";");
                // Verifica se há pelo menos duas partes (nome e número de telefone)
                if (partes.length >= 2) {
                    // Cria um matcher para encontrar padrões de números de telefone na segunda parte
                    Matcher matcher = pattern.matcher(partes[1]);

                    // Itera sobre todas as ocorrências de números de telefone encontradas
                    while (matcher.find()) {
                        String numeroTelefone = matcher.group();
                        // Verifica se o indicativo está na lista especificada
                        if (numeroTelefone.startsWith("+351") || numeroTelefone.startsWith("+32")
                                || numeroTelefone.startsWith("+33") || numeroTelefone.startsWith("+39")
                                || numeroTelefone.startsWith("+41") || numeroTelefone.startsWith("+43")
                                || numeroTelefone.startsWith("+44") || numeroTelefone.startsWith("+49")) {
                            // Incrementa o contador no objeto compartilhado
                            contador.incrementar();
                        }
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

