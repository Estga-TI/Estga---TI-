package pt.ua.edp;

class Contador {
    // Variável usada para contar ocorrências
    private int contador = 0;

    // Método para incrementar o contador
    public synchronized void incrementar() {
        contador++;
    }

    // Método para obter o valor do contador
    public synchronized int obterValor() {
        return contador;
    }
}
