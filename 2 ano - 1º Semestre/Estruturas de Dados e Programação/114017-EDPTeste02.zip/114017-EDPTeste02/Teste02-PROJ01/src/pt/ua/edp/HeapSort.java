package pt.ua.edp;

public class HeapSort {

    public void heapsort(int[] A) {
        //primeiro passo converter o array dado num HeapMáximo
        constroiHeapMaximo(A);

        //hs corresponde ao tamanho da heap a considerar (heap size)
        int hs = A.length - 1;
        //elimina todos os nós da heap!
        while (hs > 1) {
            swap(A, hs, 0);
            heapMaximo(A, 0, hs);
            hs--;
        }
        swap(A, 1, 0);
    }

    //Converte o array de inteiros A num HeapMáximo
    private void constroiHeapMaximo(int[] A) {
        int n = A.length;
        for (int i = n / 2 - 1; i >= 0; i--) {
            heapMaximo(A, i, n);
        }
    }

    /**
     * Reorganiza a subtree por forma a tornar-se um heapMaximo!
     * @param A array de inteiros a ordenar
     * @param i indice
     * @param hs comprimento da heap actual
     */
    private void heapMaximo(int[] A, int i, int hs) {
        int maior = i; // Inicializa o maior como o nó raiz
        int esquerda = 2 * i + 1;
        int direita = 2 * i + 2;

        // Se o filho da esquerda é maior que a raiz
        if (esquerda < hs && A[esquerda] > A[maior]) {
            maior = esquerda;
        }

        // Se o filho da direita é maior que a raiz
        if (direita < hs && A[direita] > A[maior]) {
            maior = direita;
        }

        // Se o maior não é a raiz
        if (maior != i) {
            swap(A, i, maior);
            heapMaximo(A, maior, hs);
        }
    }


    /**
     * Troca os valores de dois elementos em um array.
     *
     * @param vetor O array no qual a troca será realizada.
     * @param a O índice do primeiro elemento a ser trocado.
     * @param b O índice do segundo elemento a ser trocado.
     */
    public static void swap(int[] vetor, int a, int b) {
        // Armazena temporariamente o valor do elemento no índice 'a'.
        int temp = vetor[a];

        // Atribui o valor do elemento no índice 'b' ao índice 'a'.
        vetor[a] = vetor[b];

        // Atribui o valor temporário (anteriormente em 'a') ao índice 'b'.
        vetor[b] = temp;
    }
    }
