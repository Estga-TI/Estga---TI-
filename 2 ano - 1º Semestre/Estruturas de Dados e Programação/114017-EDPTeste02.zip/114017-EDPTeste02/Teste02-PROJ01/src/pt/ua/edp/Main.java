package pt.ua.edp;

import java.lang.reflect.Array;
import java.util.Arrays;

public class Main {

    public static void main(String[] args) {
        System.out.println("HEAP SORT ------------------------------------------");

        int[] numeros = { 9, 4, 1, 1, 6, 2, 3 };
        System.out.println(String.format("Array original não ordenado: %s", Arrays.toString(numeros)));
        HeapSort h = new HeapSort();
        h.heapsort(numeros);
        System.out.println(String.format("Array final ordenado: %s", Arrays.toString(numeros)));

    }
}
