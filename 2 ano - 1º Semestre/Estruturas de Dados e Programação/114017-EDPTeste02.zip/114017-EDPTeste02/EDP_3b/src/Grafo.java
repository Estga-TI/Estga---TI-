public class Grafo {
    // Valor que representa infinito
    static final int INF = Integer.MAX_VALUE;

    public static void main(String[] args) {
        // Representação da matriz de adjacências do grafo
        int[][] grafo = {
                {0, 1, INF, INF, INF, INF},
                {1, 0, INF, 1, INF, INF},
                {INF, INF, 0, 1, 1, INF},
                {INF, 1, 1, 0, INF, INF},
                {INF, INF, 1, INF, 0, 1},
                {INF, INF, INF, INF, 1, 0}
        };
        // Alterável para podermos começar e acabar em vários pontos (inicio 3 e fim 5 ou inicio 4 e fim 1)
        int pontoPartida = 5;   // Definindo o ponto de partida como 5
        int pontoChegada = 3;   // Definindo o ponto de chegada como 3

        // Chamada do método para encontrar o comprimento mínimo
        int comprimentoMinimo = encontrarComprimentoMinimo(grafo, pontoPartida, pontoChegada);

        // Apresentação do resultado
        if (comprimentoMinimo != INF) {
            System.out.println("O comprimento mínimo entre o ponto de partida e o ponto de chegada é: " + comprimentoMinimo + " Unidades de comprimento");
        } else {
            System.out.println("Não há caminho entre o ponto de partida e o ponto de chegada.");
        }
    }

    /**
     * Método para encontrar o comprimento mínimo usando o algoritmo de Floyd-Warshall.
     *
     * @param grafo     Matriz de adjacências representando o grafo.
     * @param partida   Vértice de partida.
     * @param chegada   Vértice de chegada.
     * @return          Comprimento mínimo entre os vértices de partida e chegada.
     */
    private static int encontrarComprimentoMinimo(int[][] grafo, int partida, int chegada) {
        int numVertices = grafo.length;

        // Criar uma matriz de distâncias inicializada com os valores da matriz de adjacências
        int[][] distancias = new int[numVertices][numVertices];
        for (int i = 0; i < numVertices; i++) {
            for (int j = 0; j < numVertices; j++) {
                distancias[i][j] = grafo[i][j];
            }
        }

        // Algoritmo de Floyd-Warshall para encontrar os comprimentos mínimos
        for (int k = 0; k < numVertices; k++) {
            for (int i = 0; i < numVertices; i++) {
                for (int j = 0; j < numVertices; j++) {
                    // Atualiza a distância mínima se um caminho mais curto for encontrado
                    if (distancias[i][k] != INF && distancias[k][j] != INF && distancias[i][k] + distancias[k][j] < distancias[i][j]) {
                        distancias[i][j] = distancias[i][k] + distancias[k][j];
                    }
                }
            }
        }

        // Retornar o comprimento mínimo entre o ponto de partida e o ponto de chegada
        return distancias[partida][chegada];
    }
}
